# Illustration Guidelines

Guidelines for Equal Experts illustration style and usage.

---

## Overview

These rules govern the creation and use of illustrations in Equal Experts materials.

---

## Key Principles

1. **Purposeful** - Illustrations should clarify or enhance understanding
2. **Consistent** - Unified style across all illustrations
3. **Brand-aligned** - Use brand colors and visual language
4. **Accessible** - Don't rely on illustration alone to convey critical information

---

## Illustration Style

- Clean, modern aesthetic
- Use brand color palette
- Minimal detail, focus on clarity
- Consistent with overall brand visual language

---

## To Be Defined

- Illustration style guide
- Character/people illustration guidelines
- Abstract vs representational guidance
- Color usage in illustrations
- Line weights and stroke styles
- Shadow and depth treatment
- Animation guidelines (if applicable)
- File formats and export specifications

---

## Related Documentation

- [Graphics Overview](./README.md)
- [Colours](../../../../design-language/colours.md) - Color palette
